package ir.farbord.diagfarbord.domain.obd

/**
 * تفسیر پاسخ‌های خام PID استاندارد Mode 01 به مقادیر مهندسی.
 * ورودی نمونه (بدون header، بدون space): "410C1AF8" -> RPM
 */
object PidParser {

    private fun hexBytes(raw: String): List<Int>? {
        val clean = raw.replace(" ", "").replace("\r", "").replace("\n", "")
        if (clean.length < 6 || !clean.startsWith("41")) return null
        val bytes = clean.substring(4) // skip "41" + PID id
        if (bytes.length % 2 != 0) return null
        return bytes.chunked(2).map { it.toInt(16) }
    }

    /** دور موتور RPM از PID 0C -> ((A*256)+B)/4 */
    fun parseRpm(raw: String): Double? {
        val b = hexBytes(raw) ?: return null
        if (b.size < 2) return null
        return ((b[0] * 256) + b[1]) / 4.0
    }

    /** سرعت خودرو از PID 0D -> A (km/h) */
    fun parseSpeed(raw: String): Int? {
        val b = hexBytes(raw) ?: return null
        return b.getOrNull(0)
    }

    /** دمای آب موتور از PID 05 -> A - 40 (°C) */
    fun parseCoolantTemp(raw: String): Int? {
        val b = hexBytes(raw) ?: return null
        return b.getOrNull(0)?.minus(40)
    }

    /** دمای هوای ورودی از PID 0F -> A - 40 (°C) */
    fun parseIntakeAirTemp(raw: String): Int? {
        val b = hexBytes(raw) ?: return null
        return b.getOrNull(0)?.minus(40)
    }

    /** فشار منیفولد MAP از PID 0B -> A (kPa) */
    fun parseMap(raw: String): Int? {
        val b = hexBytes(raw) ?: return null
        return b.getOrNull(0)
    }

    /** میزان دریچه گاز از PID 11 -> A*100/255 (%) */
    fun parseThrottlePosition(raw: String): Double? {
        val b = hexBytes(raw) ?: return null
        return b.getOrNull(0)?.let { it * 100.0 / 255.0 }
    }

    /** بار موتور از PID 04 -> A*100/255 (%) */
    fun parseEngineLoad(raw: String): Double? {
        val b = hexBytes(raw) ?: return null
        return b.getOrNull(0)?.let { it * 100.0 / 255.0 }
    }

    /** ولتاژ باتری معمولاً از دستور اختصاصی ATRV خوانده می‌شود، نه Mode01 */
    fun parseBatteryVoltage(rawAtRvResponse: String): Double? {
        // پاسخ نمونه ATRV: "12.6V"
        val clean = rawAtRvResponse.replace("V", "").trim()
        return clean.toDoubleOrNull()
    }

    /** استخراج کدهای DTC از پاسخ Mode 03، هر کد ۴ کاراکتر هگز */
    fun parseDtcCodes(raw: String): List<String> {
        val clean = raw.replace(" ", "").replace("\r", "").replace("\n", "")
        if (!clean.startsWith("43")) return emptyList()
        val body = clean.substring(2)
        val codes = mutableListOf<String>()
        var i = 0
        while (i + 4 <= body.length) {
            val chunk = body.substring(i, i + 4)
            if (chunk != "0000") {
                codes.add(decodeDtc(chunk))
            }
            i += 4
        }
        return codes
    }

    private fun decodeDtc(chunk: String): String {
        val firstNibble = chunk[0].digitToInt(16)
        val prefix = when (firstNibble shr 2) {
            0 -> "P" // Powertrain
            1 -> "C" // Chassis
            2 -> "B" // Body
            else -> "U" // Network
        }
        val firstDigit = firstNibble and 0x03
        return "$prefix$firstDigit${chunk.substring(1)}"
    }
}

/** لیست PIDهای استاندارد Mode 01 مورد استفاده در داشبورد */
enum class StandardPid(val code: String, val label: String, val unit: String) {
    ENGINE_LOAD("0104", "بار موتور", "%"),
    COOLANT_TEMP("0105", "دمای آب موتور", "°C"),
    INTAKE_MAP("010B", "فشار منیفولد MAP", "kPa"),
    RPM("010C", "دور موتور", "rpm"),
    SPEED("010D", "سرعت خودرو", "km/h"),
    INTAKE_AIR_TEMP("010F", "دمای هوای ورودی", "°C"),
    THROTTLE_POS("0111", "میزان دریچه گاز", "%"),
    O2_SENSOR("0114", "سنسور اکسیژن بانک ۱", "V"),
    RUNTIME("011F", "زمان کارکرد موتور", "s"),
    FUEL_PRESSURE("010A", "فشار سوخت", "kPa"),
    DISTANCE_WITH_MIL("0121", "مسافت با چراغ چک روشن", "km"),
}
