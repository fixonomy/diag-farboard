package ir.farbord.diagfarbord.domain.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * مدیریت اتصال به دانگل‌های OBD-II (ELM327 / OBDLink) از طریق Bluetooth Classic (SPP).
 * نسخه BLE در کلاس جداگانه‌ای (ObdBleConnectionManager) پیاده می‌شود چون
 * نیازمند GATT profile متفاوتی است.
 */
enum class ObdLinkQuality { DISCONNECTED, CONNECTING, CONNECTED_NO_ECU, CONNECTED_ECU_OK }

class ObdConnectionManager {

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    private val _linkQuality = MutableStateFlow(ObdLinkQuality.DISCONNECTED)
    val linkQuality: StateFlow<ObdLinkQuality> = _linkQuality

    private var currentProtocol: ObdProtocol = ObdProtocol.AUTO

    @SuppressLint("MissingPermission")
    suspend fun connect(device: BluetoothDevice): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            _linkQuality.value = ObdLinkQuality.CONNECTING
            BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
            val sock = device.createRfcommSocketToServiceRecord(sppUuid)
            sock.connect()
            socket = sock
            input = sock.inputStream
            output = sock.outputStream

            initializeElm327()
            _linkQuality.value = ObdLinkQuality.CONNECTED_ECU_OK
            Result.success(Unit)
        } catch (e: Exception) {
            _linkQuality.value = ObdLinkQuality.DISCONNECTED
            Result.failure(e)
        }
    }

    /** دستورات AT اولیه استاندارد برای آماده‌سازی ELM327 و تشخیص خودکار پروتکل */
    private suspend fun initializeElm327() {
        sendRaw("ATZ")      // ریست
        sendRaw("ATE0")     // خاموش کردن echo
        sendRaw("ATL0")     // خاموش کردن line feed
        sendRaw("ATS0")     // خاموش کردن space
        sendRaw("ATH0")     // خاموش کردن header
        sendRaw("ATSP0")    // تشخیص خودکار پروتکل (ISO9141-2 / KWP2000 / CAN)
        // تست ارتباط با ECU با خواندن یک PID پایه (RPM)
        sendRaw("0100")
    }

    suspend fun setProtocol(protocol: ObdProtocol) = withContext(Dispatchers.IO) {
        currentProtocol = protocol
        sendRaw("ATSP${protocol.atCode}")
    }

    /** ارسال یک PID و گرفتن پاسخ خام هگزادسیمال */
    suspend fun requestPid(pid: String): String = withContext(Dispatchers.IO) {
        sendRaw(pid)
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        try {
            input?.close(); output?.close(); socket?.close()
        } catch (_: Exception) {
        } finally {
            _linkQuality.value = ObdLinkQuality.DISCONNECTED
        }
    }

    private fun sendRaw(command: String): String {
        val out = output ?: return ""
        val ins = input ?: return ""
        out.write("$command\r".toByteArray())
        out.flush()

        val buffer = ByteArray(1024)
        val sb = StringBuilder()
        // ELM327 پاسخ‌ها را با کاراکتر '>' پایان می‌دهد
        while (true) {
            val bytesRead = ins.read(buffer)
            if (bytesRead <= 0) break
            val chunk = String(buffer, 0, bytesRead)
            sb.append(chunk)
            if (chunk.contains('>')) break
        }
        return sb.toString().replace(">", "").trim()
    }
}

enum class ObdProtocol(val atCode: String, val label: String) {
    AUTO("0", "تشخیص خودکار"),
    ISO9141_2("3", "ISO 9141-2"),
    KWP2000_5BAUD("4", "ISO 14230 KWP2000 (5-baud)"),
    KWP2000_FAST("5", "ISO 14230 KWP2000 (fast)"),
    CAN_11B_500K("6", "ISO 15765 CAN 11bit/500k"),
    CAN_29B_500K("7", "ISO 15765 CAN 29bit/500k"),
}
