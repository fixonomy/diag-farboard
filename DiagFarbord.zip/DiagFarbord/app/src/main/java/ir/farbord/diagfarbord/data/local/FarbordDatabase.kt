package ir.farbord.diagfarbord.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import ir.farbord.diagfarbord.data.local.dao.CarDao
import ir.farbord.diagfarbord.data.local.dao.CodingOptionDao
import ir.farbord.diagfarbord.data.local.dao.DtcDao
import ir.farbord.diagfarbord.data.local.dao.EcuDao
import ir.farbord.diagfarbord.data.local.entity.CarEntity
import ir.farbord.diagfarbord.data.local.entity.CodingOptionEntity
import ir.farbord.diagfarbord.data.local.entity.DtcCodeEntity
import ir.farbord.diagfarbord.data.local.entity.EcuEntity

@Database(
    entities = [CarEntity::class, EcuEntity::class, DtcCodeEntity::class, CodingOptionEntity::class],
    version = 1,
    exportSchema = false
)
abstract class FarbordDatabase : RoomDatabase() {
    abstract fun carDao(): CarDao
    abstract fun ecuDao(): EcuDao
    abstract fun dtcDao(): DtcDao
    abstract fun codingOptionDao(): CodingOptionDao

    companion object {
        @Volatile private var INSTANCE: FarbordDatabase? = null

        fun getInstance(context: Context): FarbordDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FarbordDatabase::class.java,
                    "farbord.db"
                ).addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            val instance = INSTANCE ?: return@launch
                            instance.carDao().insertAll(SeedData.cars)
                            instance.dtcDao().insertAll(SeedData.dtcCodes)
                        }
                    }
                }).build().also { INSTANCE = it }
            }
    }
}

/** داده‌های اولیه: خودروهای پشتیبانی‌شده، چند نمونه ECU و DTCهای پرکاربرد */
object SeedData {

    val cars = listOf(
        CarEntity(brand = "ایران‌خودرو", model = "تارا V3", engineType = "TU5 توربو", ecuFamily = "Continental"),
        CarEntity(brand = "ایران‌خودرو", model = "دنا", engineType = "EF7", ecuFamily = "Bosch"),
        CarEntity(brand = "ایران‌خودرو", model = "دنا پلاس", engineType = "EF7", ecuFamily = "Bosch"),
        CarEntity(brand = "ایران‌خودرو", model = "دنا پلاس توربو", engineType = "EF7 توربو", ecuFamily = "Kense"),
        CarEntity(brand = "ایران‌خودرو", model = "رانا پلاس", engineType = "EF7", ecuFamily = "Bosch"),
        CarEntity(brand = "ایران‌خودرو", model = "سورن", engineType = "XU7", ecuFamily = "Bosch"),
        CarEntity(brand = "ایران‌خودرو", model = "سمند EF7", engineType = "EF7", ecuFamily = "Bosch"),
        CarEntity(brand = "ایران‌خودرو", model = "پژو پارس", engineType = "XU7", ecuFamily = "Bosch"),
        CarEntity(brand = "سایپا", model = "شاهین", engineType = "EF7", ecuFamily = "Kense"),
        CarEntity(brand = "سایپا", model = "کوییک", engineType = "M13/MVM", ecuFamily = "Continental"),
        CarEntity(brand = "سایپا", model = "ساینا", engineType = "M13", ecuFamily = "Continental"),
        CarEntity(brand = "سایپا", model = "تیبا", engineType = "M13", ecuFamily = "Continental"),
    )

    val dtcCodes = listOf(
        DtcCodeEntity(
            code = "P0301",
            titleFa = "احتراق ناقص سیلندر شماره ۱",
            descriptionFa = "ECU عدم احتراق منظم (misfire) را در سیلندر شماره ۱ تشخیص داده است.",
            possibleCausesFa = "خرابی شمع\nخرابی کویل\nمشکل انژکتور\nکاهش کمپرس موتور",
            relatedPartsFa = "شمع، کویل، انژکتور، واشر سرسیلندر",
            testMethodFa = "تست کمپرس سیلندر، بررسی مقاومت کویل، تست انژکتور با اسیلوسکوپ یا نویز تست",
            repairSolutionFa = "تعویض شمع/کویل معیوب، تمیزکاری یا تعویض انژکتور، در صورت افت کمپرس تعمیر مکانیکی موتور"
        ),
        DtcCodeEntity(
            code = "P0420",
            titleFa = "راندمان پایین کاتالیزور (بانک ۱)",
            descriptionFa = "اختلاف سیگنال سنسورهای اکسیژن قبل و بعد از کاتالیزور نشان‌دهنده افت کارایی مبدل کاتالیزوری است.",
            possibleCausesFa = "خرابی کاتالیزور\nنشتی اگزوز\nخرابی سنسور اکسیژن\nمشکل نسبت سوخت و هوا",
            relatedPartsFa = "کاتالیزور، سنسور اکسیژن جلو و عقب، اتصالات اگزوز",
            testMethodFa = "بررسی سیگنال دو سنسور اکسیژن با اسکن‌تول، بازرسی چشمی نشتی اگزوز",
            repairSolutionFa = "تعویض کاتالیزور در صورت اشباع، رفع نشتی اگزوز، تعویض سنسور اکسیژن معیوب"
        ),
        DtcCodeEntity(
            code = "P0171",
            titleFa = "مخلوط سوخت و هوا بیش از حد رقیق (بانک ۱)",
            descriptionFa = "سیستم سوخت‌رسانی برای جبران مخلوط رقیق، سوخت بیشتری تزریق می‌کند اما به حد مجاز رسیده است.",
            possibleCausesFa = "نشتی هوای اضافی (وکیوم لیک)\nخرابی سنسور MAF\nضعف پمپ بنزین\nگرفتگی فیلتر سوخت\nخرابی انژکتور",
            relatedPartsFa = "شیلنگ‌های وکیوم، سنسور MAF، پمپ بنزین، فیلتر بنزین، انژکتورها",
            testMethodFa = "اسپری کارور برای یافتن نشتی هوا، بررسی فشار سوخت، بررسی داده زنده MAF",
            repairSolutionFa = "رفع نشتی هوا، تمیزکاری یا تعویض سنسور MAF، تعویض فیلتر یا پمپ بنزین معیوب"
        ),
    )
}
