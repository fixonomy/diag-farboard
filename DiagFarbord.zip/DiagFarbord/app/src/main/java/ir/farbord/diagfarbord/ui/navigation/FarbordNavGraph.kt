package ir.farbord.diagfarbord.ui.navigation

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BuildCircle
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ir.farbord.diagfarbord.ui.screens.*

sealed class FarbordRoute(val route: String, val labelFa: String) {
    object Home : FarbordRoute("home", "خانه")
    object DeviceSelect : FarbordRoute("device_select", "انتخاب دستگاه")
    object Dashboard : FarbordRoute("dashboard", "داشبورد")
    object Dtc : FarbordRoute("dtc", "خطایابی")
    object Coding : FarbordRoute("coding", "کدینگ")
    object ActuatorTest : FarbordRoute("actuator", "تست عملگر")
}

@SuppressLint("MissingPermission")
@Composable
fun FarbordNavGraph() {
    val navController = rememberNavController()

    val bottomTabs = listOf(
        FarbordRoute.Dashboard to Icons.Filled.Dashboard,
        FarbordRoute.Dtc to Icons.Filled.Warning,
        FarbordRoute.Coding to Icons.Filled.Settings,
        FarbordRoute.ActuatorTest to Icons.Filled.BuildCircle,
    )

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute in bottomTabs.map { it.first.route }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomTabs.forEach { (route, icon) ->
                        NavigationBarItem(
                            selected = currentRoute == route.route,
                            onClick = {
                                navController.navigate(route.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(icon, contentDescription = route.labelFa) },
                            label = { Text(route.labelFa) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = FarbordRoute.Home.route,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(FarbordRoute.Home.route) {
                HomeScreen(onStartConnection = {
                    navController.navigate(FarbordRoute.DeviceSelect.route)
                })
            }
            composable(FarbordRoute.DeviceSelect.route) {
                val pairedDevices = BluetoothAdapter.getDefaultAdapter()
                    ?.bondedDevices?.toList() ?: emptyList()
                DeviceSelectScreen(
                    pairedDevices = pairedDevices,
                    onDeviceSelected = {
                        // در پیاده‌سازی کامل: obdConnectionManager.connect(it) در یک ViewModel مشترک
                        navController.navigate(FarbordRoute.Dashboard.route) {
                            popUpTo(FarbordRoute.Home.route) { inclusive = false }
                        }
                    }
                )
            }
            composable(FarbordRoute.Dashboard.route) { DashboardScreen() }
            composable(FarbordRoute.Dtc.route) { DtcScreen() }
            composable(FarbordRoute.Coding.route) { CodingScreen() }
            composable(FarbordRoute.ActuatorTest.route) { ActuatorTestScreen() }
        }
    }
}
