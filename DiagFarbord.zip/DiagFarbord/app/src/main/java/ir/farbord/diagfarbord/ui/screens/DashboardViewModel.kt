package ir.farbord.diagfarbord.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.farbord.diagfarbord.domain.model.SensorInfo
import ir.farbord.diagfarbord.domain.model.SensorReading
import ir.farbord.diagfarbord.domain.obd.ObdConnectionManager
import ir.farbord.diagfarbord.domain.obd.PidParser
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val obd: ObdConnectionManager
) : ViewModel() {

    private val _readings = MutableStateFlow<List<SensorReading>>(emptyList())
    val readings: StateFlow<List<SensorReading>> = _readings

    private var polling = false

    fun startPolling() {
        if (polling) return
        polling = true
        viewModelScope.launch {
            while (polling) {
                refreshOnce()
                delay(800) // فرکانس بروزرسانی داشبورد؛ قابل تنظیم بر اساس سرعت لینک
            }
        }
    }

    fun stopPolling() {
        polling = false
    }

    private suspend fun refreshOnce() {
        val rpmRaw = obd.requestPid("010C")
        val speedRaw = obd.requestPid("010D")
        val coolantRaw = obd.requestPid("0105")
        val iatRaw = obd.requestPid("010F")
        val mapRaw = obd.requestPid("010B")
        val throttleRaw = obd.requestPid("0111")
        val loadRaw = obd.requestPid("0104")
        val voltageRaw = obd.requestPid("ATRV")

        val rpm = PidParser.parseRpm(rpmRaw)
        val speed = PidParser.parseSpeed(speedRaw)
        val coolant = PidParser.parseCoolantTemp(coolantRaw)
        val iat = PidParser.parseIntakeAirTemp(iatRaw)
        val map = PidParser.parseMap(mapRaw)
        val throttle = PidParser.parseThrottlePosition(throttleRaw)
        val load = PidParser.parseEngineLoad(loadRaw)
        val voltage = PidParser.parseBatteryVoltage(voltageRaw)

        _readings.value = listOfNotNull(
            reading("rpm", "دور موتور RPM", rpm?.let { "%.0f".format(it) } ?: "--", "rpm", (rpm ?: 0.0) > 1100),
            reading("speed", "سرعت خودرو", speed?.toString() ?: "--", "km/h"),
            reading("coolant_temp", "دمای آب موتور", coolant?.toString() ?: "--", "°C", (coolant ?: 0) > 108),
            reading("intake_air_temp", "دمای هوای ورودی", iat?.toString() ?: "--", "°C"),
            reading("map", "فشار منیفولد MAP", map?.toString() ?: "--", "kPa"),
            reading("throttle", "میزان دریچه گاز", throttle?.let { "%.1f".format(it) } ?: "--", "%"),
            reading("engine_load", "میزان بار موتور", load?.let { "%.1f".format(it) } ?: "--", "%"),
            reading("battery_voltage", "ولتاژ باتری", voltage?.toString() ?: "--", "V", voltage != null && voltage < 11.8),
        )
    }

    private fun reading(
        key: String,
        label: String,
        value: String,
        unit: String,
        outOfRange: Boolean = false
    ): SensorReading {
        val info = SensorInfo.descriptions[key]
        return SensorReading(
            key = key,
            label = label,
            value = value,
            unit = unit,
            standardRange = info?.first ?: "-",
            descriptionFa = info?.second ?: "",
            isOutOfRange = outOfRange
        )
    }

    override fun onCleared() {
        super.onCleared()
        polling = false
    }
}
