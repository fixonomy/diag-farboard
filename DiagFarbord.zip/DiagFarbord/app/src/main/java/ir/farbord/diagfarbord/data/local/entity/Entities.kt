package ir.farbord.diagfarbord.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cars")
data class CarEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val brand: String,          // ایران‌خودرو / سایپا
    val model: String,          // دنا پلاس توربو، شاهین، ...
    val engineType: String,     // نوع موتور مثل EF7، TU5، ...
    val ecuFamily: String       // Kense, Bosch, Continental
)

@Entity(tableName = "ecus")
data class EcuEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val carId: Long,
    val ecuName: String,        // مثلا Kense S180
    val hardwareNumber: String,
    val softwareNumber: String,
    val supportedProtocol: String
)

@Entity(tableName = "dtc_codes")
data class DtcCodeEntity(
    @PrimaryKey val code: String,           // P0301
    val titleFa: String,                    // احتراق ناقص سیلندر شماره ۱
    val descriptionFa: String,
    val possibleCausesFa: String,           // با \n جدا شده
    val relatedPartsFa: String,
    val testMethodFa: String,
    val repairSolutionFa: String
)

@Entity(tableName = "coding_options")
data class CodingOptionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ecuFamily: String,
    val key: String,          // AUTO_LOCK_ON_DRIVE, HORN_ON_LOCK, ...
    val titleFa: String,
    val descriptionFa: String,
    val requiresBackup: Boolean = true
)
