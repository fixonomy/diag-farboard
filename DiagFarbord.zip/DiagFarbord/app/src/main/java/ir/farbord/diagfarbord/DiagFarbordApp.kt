package ir.farbord.diagfarbord

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DiagFarbordApp : Application()
