package ir.farbord.diagfarbord.ui.screens

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * لیست دستگاه‌های بلوتوث جفت‌شده (ELM327 / OBDLink و مشابه).
 * اسکن BLE با فیلتر سرویس OBD می‌تواند بعدا اضافه شود.
 */
@SuppressLint("MissingPermission")
@Composable
fun DeviceSelectScreen(
    pairedDevices: List<BluetoothDevice>,
    onDeviceSelected: (BluetoothDevice) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("انتخاب دانگل OBD", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(12.dp))

        if (pairedDevices.isEmpty()) {
            Text("هیچ دستگاه جفت‌شده‌ای پیدا نشد. ابتدا دانگل OBD را در تنظیمات بلوتوث گوشی جفت کنید.")
        } else {
            LazyColumn {
                items(pairedDevices) { device ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Bluetooth, contentDescription = null)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(device.name ?: "دستگاه ناشناس")
                                Text(device.address, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { onDeviceSelected(device) }) {
                                Text("اتصال")
                            }
                        }
                    }
                }
            }
        }
    }
}
