package ir.farbord.diagfarbord.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun DtcScreen(viewModel: DtcViewModel = hiltViewModel()) {
    val results by viewModel.results.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val message by viewModel.clearMessage.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("خطایابی خودرو", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(12.dp))

        Row {
            Button(onClick = { viewModel.scanErrors() }, enabled = !isScanning) {
                Text(if (isScanning) "در حال اسکن..." else "اسکن خطاها")
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(onClick = { viewModel.clearErrors() }) {
                Text("پاک کردن خطاها")
            }
        }

        message?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.primary)
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (results.isEmpty() && !isScanning) {
            Text("خطایی یافت نشد یا هنوز اسکن انجام نشده است.")
        }

        LazyColumn {
            items(results) { result ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(result.code, fontWeight = FontWeight.Bold)
                            Text(result.info?.titleFa ?: "توضیح در دیتابیس موجود نیست")
                        }
                        result.info?.let { info ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("توضیح: ${info.descriptionFa}")
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("علت‌های احتمالی:\n${info.possibleCausesFa}")
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("قطعات مرتبط: ${info.relatedPartsFa}")
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("روش تست: ${info.testMethodFa}")
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("راهکار تعمیر: ${info.repairSolutionFa}")
                        }
                    }
                }
            }
        }
    }
}
