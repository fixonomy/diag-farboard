package ir.farbord.diagfarbord.di

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import ir.farbord.diagfarbord.data.local.FarbordDatabase
import ir.farbord.diagfarbord.domain.obd.ObdConnectionManager
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): FarbordDatabase =
        FarbordDatabase.getInstance(context)

    @Provides
    fun provideCarDao(db: FarbordDatabase) = db.carDao()

    @Provides
    fun provideEcuDao(db: FarbordDatabase) = db.ecuDao()

    @Provides
    fun provideDtcDao(db: FarbordDatabase) = db.dtcDao()

    @Provides
    fun provideCodingOptionDao(db: FarbordDatabase) = db.codingOptionDao()

    @Provides
    @Singleton
    fun provideObdConnectionManager(): ObdConnectionManager = ObdConnectionManager()
}
