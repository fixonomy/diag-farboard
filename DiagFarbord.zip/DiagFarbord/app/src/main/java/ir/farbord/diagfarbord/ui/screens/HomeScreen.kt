package ir.farbord.diagfarbord.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.farbord.diagfarbord.R

/**
 * صفحه اول برنامه: لوگوی فربرد در بالا، زیر آن تگ‌لاین فارسی،
 * و دکمه شروع اتصال به خودرو.
 */
@Composable
fun HomeScreen(onStartConnection: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_farbord_logo),
            contentDescription = "لوگوی فربرد",
            modifier = Modifier.size(160.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "دیاگ فربرد",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = stringResourceTagline(),
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(40.dp))

        Button(
            onClick = onStartConnection,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("اتصال به خودرو")
        }
    }
}

@Composable
private fun stringResourceTagline(): String = "دیاگ انواع خودروهای ایرانی فَربُرد"
