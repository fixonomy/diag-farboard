package ir.farbord.diagfarbord.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import ir.farbord.diagfarbord.data.local.entity.CarEntity
import ir.farbord.diagfarbord.data.local.entity.CodingOptionEntity
import ir.farbord.diagfarbord.data.local.entity.DtcCodeEntity
import ir.farbord.diagfarbord.data.local.entity.EcuEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CarDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(cars: List<CarEntity>)

    @Query("SELECT * FROM cars WHERE brand = :brand")
    fun getByBrand(brand: String): Flow<List<CarEntity>>

    @Query("SELECT * FROM cars")
    fun getAll(): Flow<List<CarEntity>>
}

@Dao
interface EcuDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(ecus: List<EcuEntity>)

    @Query("SELECT * FROM ecus WHERE carId = :carId")
    fun getForCar(carId: Long): Flow<List<EcuEntity>>
}

@Dao
interface DtcDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(codes: List<DtcCodeEntity>)

    @Query("SELECT * FROM dtc_codes WHERE code = :code LIMIT 1")
    suspend fun findByCode(code: String): DtcCodeEntity?

    @Query("SELECT * FROM dtc_codes")
    fun getAll(): Flow<List<DtcCodeEntity>>
}

@Dao
interface CodingOptionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(options: List<CodingOptionEntity>)

    @Query("SELECT * FROM coding_options WHERE ecuFamily = :ecuFamily")
    fun getForEcuFamily(ecuFamily: String): Flow<List<CodingOptionEntity>>
}
