package ir.farbord.diagfarbord.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// حس فناوری خودرو / ECU: مشکی-آبی-فیروزه‌ای با تاکید نارنجی برای هشدارها
val FarbordDarkBackground = Color(0xFF0B1220)
val FarbordSurface = Color(0xFF141C2E)
val FarbordPrimary = Color(0xFF00D1C1)   // فیروزه‌ای دیجیتال
val FarbordSecondary = Color(0xFF2E7DFF) // آبی تکنولوژی
val FarbordWarning = Color(0xFFFF9800)
val FarbordError = Color(0xFFFF4B4B)
val FarbordOnDark = Color(0xFFE7F1FF)

private val DarkColors = darkColorScheme(
    primary = FarbordPrimary,
    secondary = FarbordSecondary,
    background = FarbordDarkBackground,
    surface = FarbordSurface,
    error = FarbordError,
    onPrimary = Color.Black,
    onBackground = FarbordOnDark,
    onSurface = FarbordOnDark,
)

private val LightColors = lightColorScheme(
    primary = FarbordSecondary,
    secondary = FarbordPrimary,
    background = Color(0xFFF4F7FB),
    surface = Color.White,
    error = FarbordError,
)

@Composable
fun DiagFarbordTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
