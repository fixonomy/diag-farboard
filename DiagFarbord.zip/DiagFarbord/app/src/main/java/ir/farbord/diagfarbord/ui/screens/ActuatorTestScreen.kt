package ir.farbord.diagfarbord.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class ActuatorItem(val key: String, val titleFa: String)

/**
 * تست عملگرها با دستورات UDS Routine Control (سرویس 0x31) اجرا می‌شود.
 * شناسه دقیق روتین (Routine Identifier) برای هر عملگر به خانواده ECU بستگی دارد
 * و باید در ObdConnectionManager به‌ازای Kense/Bosch/Continental جداگانه تعریف شود.
 */
@Composable
fun ActuatorTestScreen() {
    val actuators = remember {
        listOf(
            ActuatorItem("FAN", "تست فن رادیاتور"),
            ActuatorItem("FUEL_PUMP", "تست پمپ بنزین"),
            ActuatorItem("INJECTORS", "تست انژکتورها"),
            ActuatorItem("THROTTLE", "تست دریچه گاز"),
            ActuatorItem("RELAYS", "تست رله‌ها"),
            ActuatorItem("COILS", "تست کویل‌ها"),
            ActuatorItem("SOLENOIDS", "تست شیر برقی‌ها"),
        )
    }

    var runningKey by remember { mutableStateOf<String?>(null) }
    var lastResult by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("تست عملگرها (Actuator Test)", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "قبل از هر تست، اطمینان حاصل کنید موتور در شرایط ایمن قرار دارد.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(modifier = Modifier.height(12.dp))

        lastResult?.let {
            Text(it, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
        }

        LazyColumn {
            items(actuators) { actuator ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(actuator.titleFa)
                        Button(
                            enabled = runningKey == null,
                            onClick = {
                                runningKey = actuator.key
                                // TODO: ارسال UDS Routine Control 0x31 با شناسه اختصاصی این عملگر
                                lastResult = "تست «${actuator.titleFa}» اجرا شد."
                                runningKey = null
                            }
                        ) {
                            Text(if (runningKey == actuator.key) "در حال اجرا..." else "اجرای تست")
                        }
                    }
                }
            }
        }
    }
}
