package ir.farbord.diagfarbord.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.farbord.diagfarbord.domain.model.SensorReading
import ir.farbord.diagfarbord.ui.theme.FarbordError

@Composable
fun DashboardScreen(viewModel: DashboardViewModel = hiltViewModel()) {
    val readings by viewModel.readings.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.startPolling()
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("داشبورد لحظه‌ای خودرو", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(8.dp))

        if (readings.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn {
                items(readings) { reading ->
                    SensorCard(reading)
                }
            }
        }
    }
}

@Composable
private fun SensorCard(reading: SensorReading) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(reading.label, fontWeight = FontWeight.Bold)
                Text(
                    "${reading.value} ${reading.unit}",
                    color = if (reading.isOutOfRange) FarbordError else Color.Unspecified,
                    fontWeight = FontWeight.Bold
                )
            }
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("محدوده استاندارد: ${reading.standardRange}", style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(4.dp))
                Text(reading.descriptionFa, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
