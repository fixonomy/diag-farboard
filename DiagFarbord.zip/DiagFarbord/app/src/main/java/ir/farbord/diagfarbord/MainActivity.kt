package ir.farbord.diagfarbord

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import dagger.hilt.android.AndroidEntryPoint
import ir.farbord.diagfarbord.ui.navigation.FarbordNavGraph
import ir.farbord.diagfarbord.ui.theme.DiagFarbordTheme

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // کل رابط کاربری راست‌چین (RTL) است چون برنامه فارسی است
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                DiagFarbordTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        FarbordNavGraph()
                    }
                }
            }
        }
    }
}
