package ir.farbord.diagfarbord.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class CodingItem(val key: String, val titleFa: String, val descriptionFa: String)

/**
 * بخش Coding: قبل از اعمال هر تغییر، از کاربر تایید می‌گیرد و
 * پیام می‌دهد که یک نسخه پشتیبان از تنظیمات فعلی گرفته می‌شود.
 * ارتباط واقعی با UDS Write-Data-By-Identifier باید در ObdConnectionManager
 * به ازای هر خانواده ECU (Kense/Bosch/Continental) پیاده‌سازی و تست شود،
 * چون آدرس‌های حافظه بین مدل‌ها متفاوت است.
 */
@Composable
fun CodingScreen() {
    val items = remember {
        listOf(
            CodingItem("AUTO_LOCK_DRIVE", "قفل خودکار درها بعد از حرکت", "درها بعد از رسیدن به سرعت مشخص به‌طور خودکار قفل می‌شوند."),
            CodingItem("HORN_ON_LOCK", "بوق هنگام قفل کردن با ریموت", "با فشردن دکمه قفل ریموت، یک بوق کوتاه تایید پخش می‌شود."),
            CodingItem("FLASH_ON_LOCK", "فلاشر هنگام قفل/باز کردن", "چراغ‌های راهنما هنگام قفل یا باز شدن خودرو چشمک می‌زنند."),
            CodingItem("FOLLOW_ME_HOME", "تنظیم Follow Me Home", "چراغ‌های جلو برای مدت مشخصی بعد از خاموش کردن خودرو روشن می‌مانند."),
            CodingItem("PARK_SENSOR", "تنظیم حساسیت سنسور پارک", "میزان حساسیت و صدای هشدار سنسورهای پارک قابل تنظیم است."),
            CodingItem("TPMS_RESET", "تنظیم و ریست TPMS", "بعد از تعویض یا جابجایی لاستیک‌ها، سیستم فشار باد را کالیبره می‌کند."),
            CodingItem("KOMFORT_SETTINGS", "تنظیمات Komfort", "تنظیمات رفاهی مثل بستن خودکار شیشه‌ها با ریموت."),
        )
    }

    var pendingItem by remember { mutableStateOf<CodingItem?>(null) }
    var lastAppliedMessage by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("فعال‌سازی امکانات خودرو (Coding)", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "قبل از هر تغییر، سازگاری ECU بررسی و از تنظیمات فعلی نسخه پشتیبان گرفته می‌شود.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(modifier = Modifier.height(12.dp))

        lastAppliedMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
        }

        LazyColumn {
            items(items) { item ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.titleFa)
                            Text(item.descriptionFa, style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = { pendingItem = item }) {
                            Text("اعمال")
                        }
                    }
                }
            }
        }
    }

    pendingItem?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingItem = null },
            title = { Text("تایید تغییر تنظیمات") },
            text = {
                Text(
                    "قبل از اعمال «${item.titleFa}» یک نسخه پشتیبان از تنظیمات فعلی ECU گرفته می‌شود " +
                        "تا در صورت نیاز بتوانید به حالت قبل بازگردید. آیا ادامه می‌دهید؟"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    // TODO: فراخوانی UDS WriteDataByIdentifier اختصاصی هر ECU پس از گرفتن بکاپ
                    lastAppliedMessage = "«${item.titleFa}» با موفقیت اعمال شد. نسخه پشتیبان ذخیره گردید."
                    pendingItem = null
                }) { Text("تایید و اعمال") }
            },
            dismissButton = {
                TextButton(onClick = { pendingItem = null }) { Text("انصراف") }
            }
        )
    }
}
