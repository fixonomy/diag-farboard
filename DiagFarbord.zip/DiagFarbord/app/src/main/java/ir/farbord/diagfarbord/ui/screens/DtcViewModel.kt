package ir.farbord.diagfarbord.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.farbord.diagfarbord.data.local.dao.DtcDao
import ir.farbord.diagfarbord.data.local.entity.DtcCodeEntity
import ir.farbord.diagfarbord.domain.obd.ObdConnectionManager
import ir.farbord.diagfarbord.domain.obd.PidParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DtcResult(val code: String, val info: DtcCodeEntity?)

@HiltViewModel
class DtcViewModel @Inject constructor(
    private val obd: ObdConnectionManager,
    private val dtcDao: DtcDao
) : ViewModel() {

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    private val _results = MutableStateFlow<List<DtcResult>>(emptyList())
    val results: StateFlow<List<DtcResult>> = _results

    private val _clearMessage = MutableStateFlow<String?>(null)
    val clearMessage: StateFlow<String?> = _clearMessage

    fun scanErrors() {
        viewModelScope.launch {
            _isScanning.value = true
            val raw = obd.requestPid("03") // Mode 03: Read stored DTCs
            val codes = PidParser.parseDtcCodes(raw)
            _results.value = codes.map { code ->
                DtcResult(code = code, info = dtcDao.findByCode(code))
            }
            _isScanning.value = false
        }
    }

    fun clearErrors() {
        viewModelScope.launch {
            obd.requestPid("04") // Mode 04: Clear DTCs and turn off MIL
            _clearMessage.value = "خطاها با موفقیت پاک شدند و چراغ چک خاموش شد."
            _results.value = emptyList()
        }
    }

    fun dismissMessage() {
        _clearMessage.value = null
    }
}
